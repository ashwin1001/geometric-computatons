# Program for generation of a parallelogarm with two sides parallel to Y-axis and enclosing a set of given points

# importing packages
import math
import random


class cordinates:  # datatype for defining point
    def __init__(self):
        self.x = 0
        self.y = 0

    def __init__(self, x1, y1):
        self.x = float(x1)
        self.y = float(y1)


class Circle:  # datatype for defining circle
    """this is will take coordinate and return its area"""

    def __init__(self, co, rad):
        self.co = cordinates(co.x, co.y)
        self.rad = float(rad)

        self.area = round(math.pi * rad ** 2, 3)  # function to find area of circle


class Triangle:  # datatype for defining triangle
    """this will take coordinates and return its area"""

    def __init__(self, obja, objb, objc):
        self.obj1 = cordinates(obja.x, obja.y)
        self.obj2 = cordinates(objb.x, objb.y)
        self.obj3 = cordinates(objc.x, objc.y)
        self.area = 0.0
        self.Incentre = cordinates(0, 0)
        self.radiuslength = 0.0


class stack:  # defining stack
    def __init__(self):  # constructor
        self.items = []

    def isEmpty(self):  # for checking empty stack
        return self.items == []

    def push(self, p1):  # for pushing elements onto stack
        self.items.append(p1)

    def pop(self):  # for poping elements from stack
        return self.items.pop()

    def last(self):  # for getting the last element of the stack
        return self.items[-1]

    def second_last(self):  # getting second to last element of the stack
        return self.items[-2]

    def isempty(self):  # checking empty stack
        if len(self.items) == 0:
            return True
        else:
            return False


class tri_circles:  # datatype for storing the triangle and its incentre
    def __init__(self, triangle, circle):
        self.triangle = triangle
        self.circle = circle


class parallelogram:  # datatype for storing parallelogram
    def __init__(self, p1, p2, p3, p4):
        self.p1 = cordinates(p1.x, p1.y)
        self.p2 = cordinates(p2.x, p2.y)
        self.p3 = cordinates(p3.x, p3.y)
        self.p4 = cordinates(p4.x, p4.y)
        self.area = 0.0


set_of_coordinates = set()  # contains all the points in x y plane
sorted_coordinates = {}  # storing point in sorted order on polar angle
InitialPoint = cordinates(0, 0)  # Initial point for convex hull
points_inside = set()
convex_hull = {}  # for storing convex hull
point_stack = stack()
minX = 0.0
maxX = 0.0
min_point = cordinates(0, 0)
max_point = cordinates(0, 0)
min_area_para = {}
set_of_tri_circles = set()
parallelogram = parallelogram(cordinates(0, 0), cordinates(0, 0), cordinates(0, 0), cordinates(0, 0))
try:
    min_area_of_parallelogram = float('inf')  # defining the area of parallelogram as infinite initially
except:
    min_area_of_parallelogram = 1e30000


def compare(point1, point2):  # function for comparing point on basis of polar angle
    global points_inside
    # computing and comparing polar angle
    compute = (point1.y - InitialPoint.y) * (point2.x - InitialPoint.x) - (point2.y - InitialPoint.y) * (
        point1.x - InitialPoint.x)
    if compute > 0:
        return False
    elif compute < 0:
        return True
    else:
        x1 = (point1.x - InitialPoint.x) * (point1.x - InitialPoint.x) + (point1.y - InitialPoint.y) * (
            point1.y - InitialPoint.y)
        dist1 = math.sqrt(x1)
        x2 = (point2.x - InitialPoint.x) * (point2.x - InitialPoint.x) + (point2.y - InitialPoint.y) * (
            point2.y - InitialPoint.y)
        dist2 = math.sqrt(x2)

        if dist1 < dist2:
            newpoint1 = point1.x
            newpoint2 = point1.y
            newpoint = cordinates(newpoint1, newpoint2)
            points_inside.add(newpoint)
            return False
        else:
            newpoint1 = point2.x
            newpoint2 = point2.y
            newpoint = cordinates(newpoint1, newpoint2)
            points_inside.add(newpoint)
            return False


def find_initial_point(cordinateSet):  # finding initial point of the convex hull(lower left most point)
    global InitialPoint
    for point in cordinateSet:
        break
    InitialPoint.x = point.x
    InitialPoint.y = point.y

    for points in cordinateSet:  # comparing all the points to find the minimal
        if points.y < InitialPoint.y:
            InitialPoint.x = points.x
            InitialPoint.y = points.y
        if points.y == InitialPoint.y and points.x < InitialPoint.x:
            InitialPoint.x = points.x
            InitialPoint.y = points.y


def sort_points_on_polar_angle():  # function for sorting points on basis of polar angle
    # copy points from set to dictionary
    global set_of_coordinates
    i = 1
    for point in set_of_coordinates:
        if point.x == InitialPoint.x and point.y == InitialPoint.y:  # skip for initial points
            continue

        x1 = point.x
        y1 = point.y
        newpoint = cordinates(x1, y1)
        sorted_coordinates[i] = newpoint
        i += 1
    # apply sorting
    j = 1
    for k, value in sorted_coordinates.iteritems():
        for key, val in sorted_coordinates.iteritems():
            if key <= k:
                continue
            if compare(val, value):
                pointnew1 = value.x
                pointnew2 = value.y
                value.x = val.x
                value.y = val.y
                val.x = pointnew1
                val.y = pointnew2


def generate_cor():  # function for generating random co-ordinates
    x = random.uniform(-100, 100)
    y = random.uniform(-100, 100)
    newcor = cordinates(x, y)
    return newcor


def gen1():  # function for giving hard-code values
    global set_of_coordinates
    set_of_coordinates.add(cordinates(2.1, 2))
    set_of_coordinates.add(cordinates(3, 3.1))
    set_of_coordinates.add(cordinates(5, 3))
    set_of_coordinates.add(cordinates(1, 7))
    set_of_coordinates.add(cordinates(5, 4.4))
    set_of_coordinates.add(cordinates(4, 8))
    set_of_coordinates.add(cordinates(1, 4))
    set_of_coordinates.add(cordinates(5, 1))
    set_of_coordinates.add(cordinates(3, 3.7))
    set_of_coordinates.add(cordinates(9, 3))


def check_for_right_turn(p, q, r):  # function for checking the right turn between three points
    check = (q.x - p.x) * (r.y - p.y) - (q.y - p.y) * (r.x - p.x)
    if check < 0:
        return True
    else:
        return False


def find_convex_hull():  # function for finding the convex hull
    global convex_hull
    value = sorted_coordinates[1]
    newpointx = value.x
    newpointy = value.y
    newpoint1 = cordinates(newpointx, newpointy)
    newpoint2 = sorted_coordinates[1]
    global point_stack

    point_stack.push(InitialPoint)
    point_stack.push(newpoint2)
    # loop for sorting elements
    for key, value in sorted_coordinates.iteritems():
        key1 = int(key)
        if key1 < 2:
            continue
        point = sorted_coordinates[key]

        while check_for_right_turn(point_stack.second_last(), point_stack.last(), point):
            point_stack.pop()
        point_stack.push(point)

    while not point_stack.isempty():
        pointn1 = point_stack.pop()
        pointx = pointn1.x
        pointy = pointn1.y
        pointn = cordinates(pointx, pointy)

        convex_hull[len(convex_hull) + 1] = pointn
    new1 = convex_hull[1].x
    new2 = convex_hull[1].y
    newinitpoint = cordinates(new1, new2)
    convex_hull[len(convex_hull) + 1] = newinitpoint


def calculate_area(point1, point2):  # function for calculating convex hull
    global min_area_para, min_area_of_parallelogram, parallelogram
    distant_point = cordinates(0, 0)
    distance = 0.0
    if (point1.x - point2.x) == 0:
        return
    else:
        slope = (point2.y - point1.y) / (point2.x - point1.x)  # calculating slope of line
        y1 = slope * (min_point.x - point1.x) + point1.y
        y2 = slope * (max_point.x - point1.x) + point1.y
        c1 = point1.y - slope * point1.x

        for key, val in convex_hull.iteritems():  # finding point with maximum distance
            c2 = val.y - slope * val.x
            dist = (abs(c1 - c2)) / math.sqrt(1 + slope * slope)
            if dist > distance:
                distance = dist
                distant_point.x = val.x
                distant_point.y = val.y
        y3 = slope * (min_point.x - distant_point.x) + distant_point.y
        y4 = slope * (max_point.x - distant_point.x) + distant_point.y
        area = abs(max_point.x - min_point.x) * abs(y1 - y3)  # calculating area of parallelogram
        if area < min_area_of_parallelogram:
            min_area_para[1] = cordinates(min_point.x, y1)
            min_area_para[2] = cordinates(max_point.x, y2)
            min_area_para[3] = cordinates(min_point.x, y3)
            min_area_para[4] = cordinates(max_point.x, y4)
            min_area_of_parallelogram = area;
            parallelogram.p1 = cordinates(min_point.x, y1)
            parallelogram.p2 = cordinates(max_point.x, y2)
            parallelogram.p3 = cordinates(min_point.x, y3)
            parallelogram.p4 = cordinates(max_point.x, y4)
            parallelogram.area = area


def find_min_area_para():  # find parallelogram with minimum area
    global min_point, max_point

    for key, value in convex_hull.iteritems():
        break
    min_point.x = value.x
    min_point.y = value.y
    max_point.x = value.x
    max_point.y = value.y
    for k, val in convex_hull.iteritems():
        if min_point.x > val.x:
            min_point.x = val.x
            min_point.y = val.y
        if max_point.x < val.x:
            max_point.x = val.x
            max_point.y = val.y

    for key, value in convex_hull.iteritems():
        key2 = key
        key1 = int(key2)
        key1 += 1
        keynew = str(key1)
        for k, val in convex_hull.iteritems():
            if k <= key:
                continue
            if k > key + 1:
                continue
            calculate_area(value, val)


def find_third_point(point1, point2):  # given two point of an equilateral triangle find the third point
    dx = point2.x - point1.x
    dy = point2.y - point1.y
    # rotating 60 degree about a point
    xcor = (math.cos(math.radians(60))) * dx - (math.sin(math.radians(60))) * dy + point1.x
    ycor = (math.sin(math.radians(60))) * dx + (math.cos(math.radians(60))) * dy + point1.y
    third_point = cordinates(xcor, ycor)
    dist = math.sqrt((point1.x - third_point.x) * (point1.x - third_point.x) + (point1.y - third_point.y) * (
        point1.y - third_point.y))
    return third_point


# computing the incentre and the radius of incircle of the given equilateral triangle
def compute_trinagle_para(triangle):
    sum1 = triangle.obj1.x * (triangle.obj2.y - triangle.obj3.y) + triangle.obj2.x * (
        triangle.obj3.y - triangle.obj1.y) + triangle.obj3.x * (triangle.obj1.y - triangle.obj2.y)
    triangle.area = sum1 / 2
    # calculating the distance of the sides of the equilateral triangle
    dist1 = math.sqrt((triangle.obj2.x - triangle.obj3.x) * (triangle.obj2.x - triangle.obj3.x) + (
        triangle.obj2.y - triangle.obj3.y) * (triangle.obj2.y - triangle.obj3.y))
    dist2 = math.sqrt((triangle.obj1.x - triangle.obj3.x) * (triangle.obj1.x - triangle.obj3.x) + (
        triangle.obj1.y - triangle.obj3.y) * (triangle.obj1.y - triangle.obj3.y))
    dist3 = math.sqrt((triangle.obj2.x - triangle.obj1.x) * (triangle.obj2.x - triangle.obj1.x) + (
        triangle.obj2.y - triangle.obj1.y) * (triangle.obj2.y - triangle.obj1.y))
    determinant = dist2 + dist1 + dist3
    incenx = (dist1 / determinant) * triangle.obj1.x + (dist2 / determinant) * triangle.obj2.x + (
                                                                                                     dist3 / determinant) * triangle.obj3.x
    inceny = (dist1 / determinant) * triangle.obj1.y + (dist2 / determinant) * triangle.obj2.y + (
                                                                                                     dist3 / determinant) * triangle.obj3.y
    triangle.Incentre = cordinates(incenx, inceny)

    slope = (triangle.obj3.y - triangle.obj2.y) / (triangle.obj3.x - triangle.obj2.x)
    c1 = triangle.obj3.y - slope * triangle.obj3.x
    c2 = triangle.Incentre.y - slope * triangle.Incentre.x
    triangle.radiuslength = abs(c1 - c2) / math.sqrt(1 + slope * slope)


def generate_triangles(m):  # function to generate triangle
    while m > 0:
        point1 = generate_cor()
        point2 = generate_cor()
        dist = math.sqrt((point2.x - point1.x) * (point2.x - point1.x) + (point2.y - point1.y) * (point2.y - point1.y))
        if dist < 50:
            continue
        else:
            point3 = find_third_point(point1, point2)  # find third point
            tri = Triangle(point1, point2, point3)
            compute_trinagle_para(tri)
            circ = Circle(tri.Incentre, tri.radiuslength)
            tri_circ = tri_circles(tri, circ)
            set_of_tri_circles.add(tri_circ)
            set_of_coordinates.add(cordinates(point1.x, point1.y))
            set_of_coordinates.add(cordinates(point2.x, point2.y))
            set_of_coordinates.add(cordinates(point3.x, point3.y))
            m -= 1


def generate_dot():  # function for generating dot file
    file_new = open('output.dot', 'w')  # opening the .dot and assigning to file_new for further processing
    file_new.write('graph{\n')  # writes in the .dot file for the creation of visual graph via GraphViz
    file_new.write('inv_node [style=invis, pos="-200,-200!"]\n')
    file_new.write('inv_node_corner [style=invis, pos="200,200!"]\n')
    j = 1

    for k in set_of_tri_circles:
        # drawing triangle
        file_new.write(str(j)),
        file_new.write('[shape = point, pos="%f,%f!"]\n' % (k.triangle.obj1.x, k.triangle.obj1.y))
        j += 1
        file_new.write(str(j) + ' [shape = point, pos="%f,%f!"]\n' % (k.triangle.obj2.x, k.triangle.obj2.y))
        j += 1
        file_new.write(str(j) + ' [shape = point, pos="%f,%f!"]\n' % (k.triangle.obj3.x, k.triangle.obj3.y))
        file_new.write(str(j - 2) + " -- " + str(j - 1) + " -- " + str(j) + " -- " + str(j - 2) + '\n [color=red]')
        j += 1
        # drawing circle
        file_new.write(str(
            j) + ' [shape = circle,fillcolor=skyblue,style=filled, pos = "%f,%f!", width =%f , fixedsize=true]\n' % (
                           k.circle.co.x, k.circle.co.y, k.circle.rad * 2 / 72))
        j += 1
    # drawing parallelogram
    file_new.write(str(j) + ' [shape = point, pos = "%f,%f!"\n]' % (parallelogram.p1.x, parallelogram.p1.y))
    j += 1
    file_new.write(str(j) + ' [shape = point, pos = "%f,%f!"\n]' % (parallelogram.p2.x, parallelogram.p2.y))
    j += 1
    file_new.write(str(j) + ' [shape = point, pos = "%f,%f!"\n]' % (parallelogram.p3.x, parallelogram.p3.y))
    j += 1
    file_new.write(str(j) + ' [shape = point, pos = "%f,%f!"\n]' % (parallelogram.p4.x, parallelogram.p4.y))
    file_new.write(
        str(j - 3) + " -- " + str(j - 2) + " -- " + str(j) + " -- " + str(j - 1) + " -- " + str(
            j - 3) + '\n[color=blue]')

    file_new.write("}")
    file_new.close()


def generate_graph():  # drawing graph
    generate_dot()
    from subprocess import check_call  # imports and executes the command of Graphviz
    check_call(['neato', '-n', '-Tpng', 'output.dot', '-o', 'output.png'])


def print_data():  # printing data
    print 'set of tri circles\n'
    i = 1
    for k in set_of_tri_circles:
        print 'Triangle ' + str(i)
        i += 1
        print "---(%f,%f),(%f,%f),(%f,%f) Area: %f" % \
              (k.triangle.obj1.x, k.triangle.obj1.y, k.triangle.obj2.x,
               k.triangle.obj2.y, k.triangle.obj3.x, k.triangle.obj3.y, k.triangle.area)
        print '\tEnclosing circle -- ( %f , %f , %f )\tArea:%f' % (
            k.circle.co.x, k.circle.co.y, k.circle.rad, k.circle.area)

    print '\n'
    print 'Parallelogram enclosing all triangles-'
    print "--( %f , %f ),( %f , %f ),( %f , %f ),( %f , %f )" \
          % (parallelogram.p1.x, parallelogram.p1.y, parallelogram
             .p2.x, parallelogram.p2.y, parallelogram.p3.x, parallelogram.p3.y, parallelogram.p4.x, parallelogram.p4.y)


if __name__ == "__main__":
    m = int(raw_input("Enter the number of triangles"))  # accepting input from user
    if m <= 0:
        print 'please a valid (positive non zero) number for triangles.'
        exit()
    generate_triangles(m)  # generate m triangles
    find_initial_point(set_of_coordinates)  # find initial point
    sort_points_on_polar_angle()  # sort points on basis of polar angle
    find_convex_hull()  # finding convex hull
    find_min_area_para()  # finding minimum area parallelogram
    generate_graph()  # generate graph of points
    print_data()  # print data on console
